# Tutorials how to work with JSON-SERVER

- Goal: Create fake APIs super fast! 🚀
- Who: Frontend

Happy Coding! 😜